# Liquid Glass Cam 26 — V0.1

Prototype kamera Android 11+ dengan UI glassmorphism.

- Package: `com.liquidglasscam26`
- Min SDK: 30 (Android 11)
- Target SDK: 30
- Compile SDK: 35
- Camera API: Camera2

## Build APK via GitHub Actions

1. Upload seluruh isi folder project ini ke repository GitHub.
2. Buka **Actions** → **Build Liquid Glass Cam 26** → **Run workflow**.
3. Setelah selesai, download artifact **LiquidGlassCam26-debug-apk**.
4. Ekstrak artifact dan install `app-debug.apk` di Vivo Y12s.

Workflow sudah disertakan di `.github/workflows/build.yml`.
